package com.test;

import com.test.block.ScrollContainerBlock;
import com.test.block.entity.ScrollBE;
import com.test.network.PagePayload;
import com.test.screen.ScrollScreenHandler;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.screenhandler.v1.ScreenHandlerRegistry;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.util.Identifier;

public class TestMod implements ModInitializer {

    public static final String MOD_ID = "test";

    public static final ScrollContainerBlock SCROLL_BLOCK;
    public static final Item SCROLL_ITEM;
    public static final BlockEntityType<ScrollBE> SCROLL_BE_TYPE;

    // 非 final：在 onInitialize 里由 registerSimple 赋值
    public static ScreenHandlerType<ScrollScreenHandler> SCROLL_MENU;

    static {
        SCROLL_BLOCK = new ScrollContainerBlock(AbstractBlock.Settings.create().strength(2f));
        SCROLL_ITEM = new BlockItem(SCROLL_BLOCK, new Item.Settings());
        SCROLL_BE_TYPE = BlockEntityType.Builder.create(ScrollBE::new, SCROLL_BLOCK).build(null);
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onInitialize() {
        Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "scroll_block"), SCROLL_BLOCK);
        Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "scroll_block"), SCROLL_ITEM);
        Registry.register(Registries.BLOCK_ENTITY_TYPE, Identifier.of(MOD_ID, "scroll_be"), SCROLL_BE_TYPE);

        // registerSimple 内部会完成 Registry.register，无需再手动注册
        SCROLL_MENU = ScreenHandlerRegistry.registerSimple(
                Identifier.of(MOD_ID, "scroll"),
                ScrollScreenHandler::new
        );

        // 注册翻页网络包
        PagePayload.register();
    }
}