package com.test.client.screen;

import com.test.network.PagePayload;
import com.test.screen.ScrollScreenHandler;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ScrollGuiScreen extends HandledScreen<ScrollScreenHandler> {

    private static final Identifier BG =
            Identifier.ofVanilla("textures/gui/container/generic_54.png");

    public ScrollGuiScreen(ScrollScreenHandler handler, PlayerInventory inv, Text title) {
        super(handler, inv, title);
        this.backgroundWidth = 176;
        this.backgroundHeight = 166;
    }

    @Override
    protected void init() {
        super.init();
        this.titleLabelX = (this.backgroundWidth - this.textRenderer.width(this.title)) / 2;
    }

    @Override
    protected void renderBg(DrawContext context, float delta, int mouseX, int mouseY) {
        context.drawTexture(BG, this.x, this.y, 0, 0,
                this.backgroundWidth, this.backgroundHeight, 256, 256);
    }

    @Override
    protected void drawForeground(DrawContext context, int mouseX, int mouseY) {
        super.drawForeground(context, mouseX, mouseY);
        int page = handler.getCurrentPage() + 1;
        String text = "Page " + page;
        context.drawText(this.textRenderer, text, this.backgroundWidth - 50, 6, 0x404040, false);
    }

    // ✅ 滚轮只发包，不碰 BE
    @Override
    public boolean mouseScrolled(double mouseX, double mouseY,
                                 double horizontalAmount, double verticalAmount) {
        if (verticalAmount > 0) {
            ClientPlayNetworking.send(new PagePayload(-1));
        } else if (verticalAmount < 0) {
            ClientPlayNetworking.send(new PagePayload(1));
        }
        return true;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        this.drawMouseoverTooltip(context, mouseX, mouseY);
    }
}