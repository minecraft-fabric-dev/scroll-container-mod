package com.test.block.entity;

import com.test.EmcManager; // 注意这里，按你的包结构已改为直接引用
import com.test.TestMod;
import com.test.screen.ScrollScreenHandler;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventories;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.screen.NamedScreenHandlerFactory;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.text.Text;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import org.jetbrains.annotations.Nullable;

/**
 * 只负责存储 items、持久化 currentPage、提供 GUI 工厂。
 * 翻页同步完全交给 ScreenHandler，BE 不自定义 sync / blockEvent。
 */
public class ScrollBE extends BlockEntity implements Inventory, NamedScreenHandlerFactory {

    public static final int PAGE_SIZE = 9;   // 一页 9 格
    public static final int MAX_PAGES = 5;   // 最多 5 页（45 格）

    public int currentPage = 0;

    private final DefaultedList<ItemStack> items =
            DefaultedList.ofSize(PAGE_SIZE * MAX_PAGES, ItemStack.EMPTY);

    public ScrollBE(BlockPos pos, BlockState state) {
        super(TestMod.SCROLL_BE_TYPE, pos, state);
    }

    // ==================== 懒填充 ====================

    @Nullable
    @Override
    public ScreenHandler createMenu(int syncId, PlayerInventory inv, PlayerEntity player) {
        // createMenu 只在服务端调用；再判 isClient 作为防御
        if (world != null && !world.isClient() && isEmpty()) {
            fillFromEmcList();          // ✅ 必须先填充
        }
        return new ScrollScreenHandler(syncId, inv, this);
    }

    /** 从 EMC 表拉取所有有 EMC 价值的物品，填入 items（最多 45 个） */
    private void fillFromEmcList() {
        var all = EmcManager.getAllEmcItems();
        int max = Math.min(all.size(), items.size());
        for (int i = 0; i < max; i++) {
            items.set(i, new ItemStack(all.get(i).getKey()));
        }
        // 填充后页码可能超界，夹紧一次
        currentPage = MathHelper.clamp(currentPage, 0, actualPages() - 1);
        markDirty();
    }

    // ==================== 动态页数 ====================

    /** 以 items 里实际最后一个非空槽为准，算真实页数 */
    public int actualPages() {
        int lastNonEmpty = -1;
        for (int i = items.size() - 1; i >= 0; i--) {
            if (!items.get(i).isEmpty()) {
                lastNonEmpty = i;
                break;
            }
        }
        return Math.max(1, (lastNonEmpty + 1 + PAGE_SIZE - 1) / PAGE_SIZE);
    }

    /** 只改页码，不做任何同步；同步由 ScreenHandler.requestPage 负责 */
    public void pageAdd(int delta) {
        int maxPage = actualPages() - 1;
        int newPage = MathHelper.clamp(currentPage + delta, 0, maxPage);
        if (newPage == currentPage) return;
        currentPage = newPage;
        markDirty();
    }

    // ==================== Inventory ====================

    @Override public int size() { return items.size(); }
    @Override public boolean isEmpty() { return items.stream().allMatch(ItemStack::isEmpty); }
    @Override public ItemStack getStack(int slot) { return items.get(slot); }
    @Override public ItemStack removeStack(int slot, int amount) { return Inventories.splitStack(items, slot, amount); }
    @Override public ItemStack removeStack(int slot) { return Inventories.removeStack(items, slot); }
    @Override public void setStack(int slot, ItemStack stack) { items.set(slot, stack); markDirty(); }
    @Override public boolean canPlayerUse(PlayerEntity player) { return true; }
    @Override public void clear() { items.clear(); }

    // ==================== NBT ====================

    @Override
    protected void writeNbt(NbtCompound nbt) {
        super.writeNbt(nbt);
        Inventories.writeNbt(nbt, items);
        nbt.putInt("CurrentPage", currentPage);
    }

    @Override
    public void readNbt(NbtCompound nbt) {
        super.readNbt(nbt);
        Inventories.readNbt(nbt, items);
        currentPage = nbt.getInt("CurrentPage");
    }

    // ==================== GUI ====================

    @Override
    public Text getDisplayName() {
        return Text.literal("分页容器");
    }
}