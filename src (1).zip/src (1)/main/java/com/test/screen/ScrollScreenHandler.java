package com.test.screen;

import com.test.TestMod;
import com.test.block.entity.ScrollBE;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ArrayPropertyDelegate;
import net.minecraft.screen.PropertyDelegate;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import org.jetbrains.annotations.Nullable;

/**
 * 分页容器 ScreenHandler。
 * 核心：pageCache 是当前页 9 格缓存，槽位绑定它，永不重建 slots。
 * 翻页只刷新 pageCache 内容，然后 sendContentUpdates() 同步。
 */
public class ScrollScreenHandler extends ScreenHandler {

    private final SimpleInventory pageCache;     // 当前页 9 格缓存（两端都有）
    private final PropertyDelegate pageDelegate; // 同步 currentPage
    private final ScrollBE be;                   // 客户端为 null

    // ==================== 构造器 ====================

    // 客户端构造器（registerSimple 调用）
    public ScrollScreenHandler(int syncId, PlayerInventory playerInv) {
        this(syncId, playerInv, null, new ArrayPropertyDelegate(1));
    }

    // 服务端构造器（BE.createMenu 调用）
    public ScrollScreenHandler(int syncId, PlayerInventory playerInv, ScrollBE be) {
        this(syncId, playerInv, be, new PropertyDelegate() {
            @Override public int get(int index) { return be.currentPage; }
            @Override public void set(int index, int value) { be.currentPage = value; }
            @Override public int size() { return 1; }
        });
    }

    // 统一构造器
    private ScrollScreenHandler(int syncId, PlayerInventory playerInv,
                                @Nullable ScrollBE be, PropertyDelegate delegate) {
        super(TestMod.SCROLL_MENU, syncId);
        this.be = be;
        this.pageCache = new SimpleInventory(ScrollBE.PAGE_SIZE);
        this.pageDelegate = delegate;

        // 服务端：把当前页内容填进缓存；客户端：留空等同步
        if (be != null) {
            loadPageToCache(be.currentPage);
        }

        // ===== 页面 9 格（绑定 pageCache，永不重建） =====
        for (int i = 0; i < ScrollBE.PAGE_SIZE; i++) {
            this.addSlot(new Slot(pageCache, i, 44 + (i % 3) * 18, 17 + (i / 3) * 18) {
                @Override
                public boolean canInsert(ItemStack stack) {
                    return false; // 展示型槽位，禁止手动放入
                }

                @Override
                public void onTakeItem(PlayerEntity player, ItemStack stack) {
                    super.onTakeItem(player, stack);
                    // 🔌 接转化桌时在这里扣 EMC：
                    // if (be instanceof TransmutationTableBlockEntity table) {
                    //     long cost = EmcManager.getEmc(stack.getItem()) * stack.getCount();
                    //     if (cost <= 0 || !table.consumeEmc(cost)) {
                    //         pageCache.setStack(this.getIndex(), stack.copy());
                    //         ScrollScreenHandler.this.sendContentUpdates();
                    //         return;
                    //     }
                    //     ScrollScreenHandler.this.sendContentUpdates();
                    // }
                }
            });
        }

        // ===== 玩家物品栏 =====
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.addSlot(new Slot(playerInv, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(playerInv, col, 8 + col * 18, 142));
        }

        // ✅ 页码属性同步（两端都要 addProperties）
        this.addProperties(pageDelegate);
    }

    // ==================== 页码 / 翻页 ====================

    public int getCurrentPage() {
        return pageDelegate.get(0);
    }

    public ScrollBE getBlockEntity() {
        return be;
    }

    /**
     * 服务端翻页入口：
     * 1. 改 BE 页码
     * 2. 刷新 pageCache 内容（不重建 slots）
     * 3. sendContentUpdates() 同步 pageCache + 页码到客户端
     */
    public void requestPage(int delta) {
        if (be == null) return;                  // 客户端防御
        int oldPage = be.currentPage;
        be.pageAdd(delta);
        if (be.currentPage == oldPage) return;   // 到边界，没必要广播
        refreshPageSlots();
        this.sendContentUpdates();
    }

    /** ✅ 只刷新 pageCache 内容，绝不动 slots 列表 */
    public void refreshPageSlots() {
        if (be == null) return;
        loadPageToCache(be.currentPage);
    }

    private void loadPageToCache(int page) {
        for (int i = 0; i < ScrollBE.PAGE_SIZE; i++) {
            int realIndex = page * ScrollBE.PAGE_SIZE + i;
            ItemStack stack = realIndex < be.size()
                    ? be.getStack(realIndex).copy()
                    : ItemStack.EMPTY;
            pageCache.setStack(i, stack);
        }
    }

    // ==================== 标准 quickMoveStack ====================

    @Override
    public ItemStack quickMoveStack(PlayerEntity player, int index) {
        Slot slot = this.slots.get(index);
        if (!slot.hasStack()) return ItemStack.EMPTY;

        ItemStack stack = slot.getStack();
        ItemStack original = stack.copy();

        if (index < ScrollBE.PAGE_SIZE) {
            // 🔌 接转化桌时在这里扣 EMC：
            // if (be instanceof TransmutationTableBlockEntity table) {
            //     long cost = EmcManager.getEmc(stack.getItem()) * stack.getCount();
            //     if (cost <= 0 || !table.consumeEmc(cost)) return ItemStack.EMPTY;
            // }
            // 页面槽 → 玩家背包
            if (!this.insertItem(stack, ScrollBE.PAGE_SIZE, this.slots.size(), true)) {
                return ItemStack.EMPTY;
            }
        } else {
            // 玩家背包 → 页面槽（canInsert=false，实际会失败，符合展示型预期）
            if (!this.insertItem(stack, 0, ScrollBE.PAGE_SIZE, false)) {
                return ItemStack.EMPTY;
            }
        }

        if (stack.isEmpty()) {
            slot.setStack(ItemStack.EMPTY);
        } else {
            slot.markDirty();
        }
        return original;
    }

    @Override
    public boolean canUse(PlayerEntity player) {
        return be == null || Container.stillValidBlockEntity(be, player);
    }
}