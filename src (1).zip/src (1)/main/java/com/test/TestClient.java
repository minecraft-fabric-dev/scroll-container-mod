package com.test;

import com.test.client.screen.ScrollGuiScreen;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.gui.screen.ingame.HandledScreens;

public class TestClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        // 1.21.1 必须用 HandledScreens（不是 MenuScreens）
        HandledScreens.register(TestMod.SCROLL_MENU, ScrollGuiScreen::new);
    }
}