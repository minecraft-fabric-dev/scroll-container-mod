package com.test.network;

import com.test.TestMod;
import com.test.screen.ScrollScreenHandler;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public record PagePayload(int delta) implements CustomPayload {

    // ✅ 标准构造：先 Id，再 Codec，最后组合 Type
    public static final CustomPayload.Id<PagePayload> ID =
            new CustomPayload.Id<>(Identifier.of(TestMod.MOD_ID, "page"));

    public static final PacketCodec<RegistryByteBuf, PagePayload> CODEC = PacketCodec.of(
            (payload, buf) -> buf.writeVarInt(payload.delta()),
            buf -> new PagePayload(buf.readVarInt())
    );

    public static final CustomPayload.Type<PagePayload> TYPE =
            new CustomPayload.Type<>(ID, CODEC);

    @Override
    public CustomPayload.Type<? extends CustomPayload> type() {
        return TYPE;
    }

    public static void register() {
        PayloadTypeRegistry.playC2S().register(ID, CODEC);

        ServerPlayNetworking.registerGlobalReceiver(ID, (payload, context) -> {
            context.server().execute(() -> {
                var player = context.player();
                // ✅ 判空 + 类型判断
                if (player.currentScreenHandler instanceof ScrollScreenHandler handler
                        && handler.getBlockEntity() != null) {
                    handler.requestPage(payload.delta());
                }
            });
        });
    }
