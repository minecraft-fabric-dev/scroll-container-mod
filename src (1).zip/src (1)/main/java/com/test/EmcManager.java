package com.test;

import net.minecraft.item.Item;
import net.minecraft.item.Items;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 简易 EMC 表。接数据包加载时，把 registerFromJson 换成
 * ResourceManagerHelper 读取 data/test/emc/*.json 即可。
 */
public class EmcManager {

    private static final Map<Item, Long> EMC_VALUES = new HashMap<>();

    static {
        set(Items.COBBLESTONE, 1L);
        set(Items.STONE, 1L);
        set(Items.DIRT, 1L);
        set(Items.SAND, 1L);
        set(Items.GRAVEL, 4L);
        set(Items.COAL, 32L);
        set(Items.REDSTONE, 64L);
        set(Items.IRON_INGOT, 256L);
        set(Items.QUARTZ, 256L);
        set(Items.GLOWSTONE_DUST, 384L);
        set(Items.LAPIS_LAZULI, 864L);
        set(Items.GOLD_INGOT, 2048L);
        set(Items.DIAMOND, 8192L);
        set(Items.EMERALD, 16384L);
        set(Items.NETHERITE_INGOT, 139264L);
        set(Items.IRON_BLOCK, 2304L);
        set(Items.GOLD_BLOCK, 18432L);
        set(Items.DIAMOND_BLOCK, 73728L);
        set(Items.EMERALD_BLOCK, 147456L);
        set(Items.NETHERITE_BLOCK, 1253376L);
        set(Items.APPLE, 128L);
        set(Items.BREAD, 192L);
    }

    private static void set(Item item, long emc) {
        EMC_VALUES.put(item, emc);
    }

    public static long getEmc(Item item) {
        Long value = EMC_VALUES.get(item);
        return value != null ? value : -1L;
    }

    public static boolean hasEmc(Item item) {
        return EMC_VALUES.containsKey(item);
    }

    /** 按 EMC 升序返回所有物品，供 ScrollBE 填充用 */
    public static List<Map.Entry<Item, Long>> getAllEmcItems() {
        return EMC_VALUES.entrySet().stream()
                .sorted(Map.Entry.comparingByValue())
                .toList();
    }
}